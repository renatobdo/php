<form action="/submit" method="post">
  <label for="username">Nome de usuário:</label>
  <input type="text" id="username" name="username"><br><br>
  <input type="hidden" id="secret_code" name="secret_code" value="s3cr3t"><br><br>
  <input type="submit" value="Enviar">
</form>


<form action="/upload" method="post" enctype="multipart/form-data">
  <label for="file">Selecione um arquivo para enviar:</label>
  <input type="file" id="file" name="file"><br><br>
  <input type="submit" value="Enviar Arquivo">
</form>
